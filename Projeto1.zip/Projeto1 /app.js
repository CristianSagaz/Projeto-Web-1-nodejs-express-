const express = require('express');
const { listen } = require('express/lib/application');
const app = express();

app.use(express.urlencoded({extended: true}))
app.use(express.json())

app.get("/", function(req, res){
    res.sendFile(__dirname+"/html/index.html")
})

app.get("/login", function(req, res){
    res.render("index")
})

app.post("/registro", function(req, res){
    res.send(` Nome: ${req.body.nome} ${req.body.sobrenome} <br> Email: ${req.body.email}`) 
})



app.listen(3000);